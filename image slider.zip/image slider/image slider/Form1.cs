using System;

namespace image_slider
{
    public partial class Form1 : Form
    {

        private string[] images = 
            {
             "D:\\Study\\College\\Visual programming\\image slider\\1.jpg",
             "D:\\Study\\College\\Visual programming\\image slider\\2.jpg",
             "D:\\Study\\College\\Visual programming\\image slider\\3.jpg"
             };

        int index = 0;
        public Form1()
        {
            InitializeComponent();
            pictureBox1.ImageLocation = images[index];
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {

            index = (index + 1) % images.Length; 
            pictureBox1.ImageLocation = images[index];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            index = (index - 1 + images.Length) % images.Length;
            pictureBox1.ImageLocation = images[index];
        }
    }
}
